# Smart Indian Food Delivery Billing System

## Goal
Build a complete, presentation-ready hosted application for creating an Indian food order, calculating its bill on the server, and explaining the computational-thinking decisions during a college defence.

## What I’ll build
- A desktop-first food ordering workspace with dashboard navigation, search, category filters, quantity controls, cart, coupon entry, and an invoice view.
- Twelve fully described menu items with appropriate high-quality food photos, lazy loading, and a bundled fallback illustration if an external image fails.
- A server-validated billing pipeline covering item totals, tiered discounts, coupon rules, delivery charges, 5% GST, currency rounding, duplicate handling, and clear validation errors.
- A one-click demo order and a seven-stage calculation walkthrough for live presentation.
- Dedicated sections for Computational Thinking, Architecture, Testing, Performance Analysis, AI-Assisted Software Engineering, and Defence Mode.
- Print/download-ready billing and responsive behavior for smaller screens.

## Technical details
- Keep domain models, billing strategies, validation, menu data, and interface components in separate modules.
- Use integer paise for all calculations to avoid floating-point currency errors.
- Expose billing through a typed server function so browser totals are never trusted.
- Add focused tests for all pricing thresholds, coupons, delivery bands, GST, invalid quantities, empty orders, duplicate items, and non-negative totals.
- Show only real test status in the Testing section; do not invent coverage.
- Use the hosted TanStack server runtime selected by the user; describe the original Python concepts as equivalent architecture rather than claiming Python execution.

## Verification
- Run the billing tests.
- Check the current build diagnostics.
- Exercise menu filtering, demo order, coupon application, quantity changes, checkout, and print view in the running preview.
- Verify the food imagery and fallback behavior at desktop and mobile widths.
