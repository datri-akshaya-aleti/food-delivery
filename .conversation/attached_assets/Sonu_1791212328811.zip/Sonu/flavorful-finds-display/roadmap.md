# Roadmap
- [x] Build menu data and resilient food imagery
- [x] Build and test the server-validated billing engine
- [x] Build ordering, cart, invoice, and demo flow
- [x] Add computational thinking, architecture, testing, performance, AI, and defence views
- [ ] Verify build and central user flow
