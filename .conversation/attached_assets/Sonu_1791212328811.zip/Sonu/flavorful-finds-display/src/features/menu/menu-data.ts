export type Category = "Biryani" | "Starters" | "South Indian" | "North Indian" | "Chinese" | "Desserts" | "Beverages";

export interface FoodItem {
  id: string;
  name: string;
  category: Category;
  pricePaise: number;
  description: string;
  imageUrl: string;
}

export const MENU: FoodItem[] = [
  { id: "chicken-biryani", name: "Chicken Biryani", category: "Biryani", pricePaise: 32900, description: "Fragrant basmati rice layered with slow-cooked chicken, saffron and fried onions.", imageUrl: "https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=900&q=85" },
  { id: "chicken-65", name: "Chicken 65", category: "Starters", pricePaise: 24900, description: "Crisp, fiery chicken tossed with curry leaves, chillies and house spices.", imageUrl: "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=900&q=85" },
  { id: "masala-dosa", name: "Masala Dosa", category: "South Indian", pricePaise: 17900, description: "Golden rice crêpe filled with spiced potato, served with chutney and sambar.", imageUrl: "https://images.unsplash.com/photo-1668236543090-82eba5ee5976?auto=format&fit=crop&w=900&q=85" },
  { id: "paneer-butter-masala", name: "Paneer Butter Masala", category: "North Indian", pricePaise: 28900, description: "Soft paneer in a silky tomato, cashew and butter gravy finished with cream.", imageUrl: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=900&q=85" },
  { id: "idli", name: "Idli", category: "South Indian", pricePaise: 9900, description: "Four soft steamed rice cakes with coconut chutney and comforting sambar.", imageUrl: "https://images.unsplash.com/photo-1630383249896-424e482df921?auto=format&fit=crop&w=900&q=85" },
  { id: "vada", name: "Vada", category: "South Indian", pricePaise: 10900, description: "Crisp lentil doughnuts with a fluffy centre, served hot with chutneys.", imageUrl: "https://images.unsplash.com/photo-1601050690117-94f5f6fa8bd7?auto=format&fit=crop&w=900&q=85" },
  { id: "veg-fried-rice", name: "Veg Fried Rice", category: "Chinese", pricePaise: 19900, description: "Wok-tossed rice with crunchy vegetables, spring onion and aromatic sauces.", imageUrl: "https://images.unsplash.com/photo-1603133872878-684f208fb84b?auto=format&fit=crop&w=900&q=85" },
  { id: "chicken-fried-rice", name: "Chicken Fried Rice", category: "Chinese", pricePaise: 23900, description: "Smoky wok-fried rice with tender chicken, egg, vegetables and scallions.", imageUrl: "https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=900&q=85" },
  { id: "butter-naan", name: "Butter Naan", category: "North Indian", pricePaise: 6900, description: "Tandoor-baked flatbread brushed generously with cultured butter.", imageUrl: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=85" },
  { id: "samosa", name: "Samosa", category: "Starters", pricePaise: 7900, description: "Two flaky pastries packed with spiced potato and peas, with mint chutney.", imageUrl: "https://images.unsplash.com/photo-1601050690117-94f5f6fa8bd7?auto=format&fit=crop&w=900&q=85" },
  { id: "gulab-jamun", name: "Gulab Jamun", category: "Desserts", pricePaise: 11900, description: "Warm milk-solid dumplings steeped in cardamom and rose sugar syrup.", imageUrl: "https://images.unsplash.com/photo-1666190094760-56e580995d6c?auto=format&fit=crop&w=900&q=85" },
  { id: "mango-lassi", name: "Mango Lassi", category: "Beverages", pricePaise: 12900, description: "Chilled Alphonso mango and yoghurt blended until thick and creamy.", imageUrl: "https://images.unsplash.com/photo-1626203050468-9308df5cf4f6?auto=format&fit=crop&w=900&q=85" },
];

export const CATEGORIES = ["All", ...new Set(MENU.map((item) => item.category))];