import { describe, expect, it } from "vitest";
import { calculateBill } from "./billing";

describe("billing rules", () => {
  it("calculates item totals, delivery and GST", () => {
    const bill = calculateBill({ items: [{ itemId: "idli", quantity: 2 }] });
    expect(bill.subtotal).toBe(19800);
    expect(bill.delivery).toBe(4000);
    expect(bill.gst).toBe(990);
    expect(bill.total).toBe(24790);
  });
  it.each([["idli", 6, 59400, 5940], ["chicken-biryani", 4, 131600, 19740], ["chicken-biryani", 5, 164500, 32900]])("applies tier discounts", (itemId, quantity, subtotal, discount) => {
    const bill = calculateBill({ items: [{ itemId: String(itemId), quantity: Number(quantity) }] });
    expect(bill.subtotal).toBe(subtotal); expect(bill.discount).toBe(discount);
  });
  it("uses the better valid coupon and caps discounts", () => {
    const bill = calculateBill({ items: [{ itemId: "butter-naan", quantity: 1 }], coupon: "WELCOME50" });
    expect(bill.discount).toBe(5000); expect(bill.discount).toBeLessThanOrEqual(bill.subtotal);
  });
  it("merges duplicate items", () => expect(calculateBill({ items: [{ itemId: "samosa", quantity: 1 }, { itemId: "samosa", quantity: 2 }] }).items[0]?.quantity).toBe(3));
  it("rejects empty orders, bad quantities and invalid coupons", () => {
    expect(() => calculateBill({ items: [] })).toThrow();
    expect(() => calculateBill({ items: [{ itemId: "idli", quantity: 0 }] })).toThrow();
    expect(() => calculateBill({ items: [{ itemId: "idli", quantity: 1 }], coupon: "NOPE" })).toThrow("Invalid coupon");
  });
  it("never creates negative bill components", () => {
    for (let quantity = 1; quantity <= 20; quantity++) {
      const bill = calculateBill({ items: [{ itemId: "gulab-jamun", quantity }] });
      expect(Math.min(bill.subtotal, bill.discount, bill.gst, bill.total)).toBeGreaterThanOrEqual(0);
    }
  });
});