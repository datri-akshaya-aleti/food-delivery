import { z } from "zod";
import { MENU } from "../menu/menu-data";

export const orderInputSchema = z.object({
  items: z.array(z.object({ itemId: z.string(), quantity: z.number().int().min(1).max(99) })).min(1, "Add at least one item"),
  coupon: z.string().trim().toUpperCase().max(20).optional(),
});

export type OrderInput = z.infer<typeof orderInputSchema>;

export interface BillLine { itemId: string; name: string; quantity: number; unitPrice: number; total: number }
export interface BillResult {
  orderId: string; createdAt: string; items: BillLine[]; subtotal: number; discount: number;
  discountLabel: string; delivery: number; deliveryLabel: string; gst: number; total: number; coupon?: string;
}

const tierRate = (subtotal: number) => subtotal >= 150000 ? 20 : subtotal >= 100000 ? 15 : subtotal >= 50000 ? 10 : 0;
const deliveryCharge = (subtotal: number) => subtotal >= 100000 ? 0 : subtotal >= 60000 ? 2000 : subtotal >= 30000 ? 3000 : 4000;

export function calculateBill(input: OrderInput): BillResult {
  const parsed = orderInputSchema.parse(input);
  const merged = new Map<string, number>();
  parsed.items.forEach(({ itemId, quantity }) => merged.set(itemId, (merged.get(itemId) ?? 0) + quantity));
  const lines = [...merged.entries()].map(([itemId, quantity]) => {
    const food = MENU.find((item) => item.id === itemId);
    if (!food) throw new Error(`Invalid food item: ${itemId}`);
    return { itemId, name: food.name, quantity, unitPrice: food.pricePaise, total: food.pricePaise * quantity };
  });
  const subtotal = lines.reduce((sum, line) => sum + line.total, 0);
  const rate = tierRate(subtotal);
  let discount = Math.round(subtotal * rate / 100);
  let discountLabel = rate ? `${rate}% order discount` : "No tier discount";
  if (parsed.coupon) {
    const couponDiscounts: Record<string, number> = { WELCOME50: 5000, SAVE10: Math.round(subtotal * .1), FESTIVE20: Math.round(subtotal * .2) };
    const couponDiscount = couponDiscounts[parsed.coupon];
    if (couponDiscount === undefined) throw new Error("Invalid coupon code");
    if (couponDiscount > discount) { discount = couponDiscount; discountLabel = `${parsed.coupon} coupon`; }
  }
  discount = Math.min(discount, subtotal);
  const delivery = deliveryCharge(subtotal);
  const taxable = Math.max(0, subtotal - discount);
  const gst = Math.round(taxable * .05);
  return {
    orderId: `ORD-${Date.now().toString().slice(-8)}`, createdAt: new Date().toISOString(), items: lines,
    subtotal, discount, discountLabel, delivery, deliveryLabel: delivery === 0 ? "Free delivery" : "Standard delivery", gst,
    total: taxable + delivery + gst, coupon: parsed.coupon || undefined,
  };
}