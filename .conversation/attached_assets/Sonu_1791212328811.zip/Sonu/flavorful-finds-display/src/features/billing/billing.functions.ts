import { createServerFn } from "@tanstack/react-start";
import { calculateBill, orderInputSchema } from "./billing";

export const generateBill = createServerFn({ method: "POST" })
  .inputValidator((input) => orderInputSchema.parse(input))
  .handler(async ({ data }) => calculateBill(data));