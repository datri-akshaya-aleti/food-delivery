import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Check, ChevronRight, CircleHelp, Minus, Plus, Printer, ReceiptText, Search, ShoppingBag, Sparkles, Trash2, UtensilsCrossed, X } from "lucide-react";
import { useMemo, useState } from "react";
import { Button } from "../components/Button";
import { FoodImage } from "../components/FoodImage";
import { generateBill } from "../features/billing/billing.functions";
import type { BillResult } from "../features/billing/billing";
import { CATEGORIES, MENU } from "../features/menu/menu-data";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "Order Indian Food — Rasoi Route" },
    { name: "description", content: "Build an Indian food order and see every billing decision explained." },
    { property: "og:title", content: "Order Indian Food — Rasoi Route" },
    { property: "og:description", content: "A transparent, server-validated Indian food billing experience." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ]}),
  component: Index,
});

const money = (paise: number) => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 2 }).format(paise / 100);

function Index() {
  const calculate = useServerFn(generateBill);
  const [cart, setCart] = useState<Record<string, number>>({});
  const [category, setCategory] = useState("All");
  const [search, setSearch] = useState("");
  const [coupon, setCoupon] = useState("");
  const [bill, setBill] = useState<BillResult | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const filtered = useMemo(() => MENU.filter((item) => (category === "All" || item.category === category) && item.name.toLowerCase().includes(search.toLowerCase())), [category, search]);
  const itemCount = Object.values(cart).reduce((sum, quantity) => sum + quantity, 0);
  const previewSubtotal = Object.entries(cart).reduce((sum, [id, quantity]) => sum + (MENU.find((item) => item.id === id)?.pricePaise ?? 0) * quantity, 0);

  const changeQuantity = (id: string, delta: number) => {
    setBill(null); setError("");
    setCart((current) => { const next = Math.max(0, (current[id] ?? 0) + delta); const updated = { ...current }; if (next) updated[id] = next; else delete updated[id]; return updated; });
  };
  const runBill = async () => {
    setLoading(true); setError("");
    try {
      const result = await calculate({ data: { items: Object.entries(cart).map(([itemId, quantity]) => ({ itemId, quantity })), coupon } });
      setBill(result); setCartOpen(false); setTimeout(() => document.getElementById("bill")?.scrollIntoView({ behavior: "smooth" }), 50);
    } catch (caught) { setError(caught instanceof Error ? caught.message.replace(/^.*Error: /, "") : "Could not calculate this order"); }
    finally { setLoading(false); }
  };
  const demo = () => { setCart({ "chicken-biryani": 2, "chicken-65": 1, "butter-naan": 2, "mango-lassi": 1, "gulab-jamun": 2 }); setBill(null); setCartOpen(true); };

  return <div className="min-h-screen bg-background">
    <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-[1500px] items-center gap-5 px-5 lg:px-8">
        <Link to="/" className="flex items-center gap-3"><span className="grid size-10 place-items-center rounded-md bg-primary text-primary-foreground"><UtensilsCrossed size={20}/></span><span><b className="block font-display text-lg leading-none">Rasoi Route</b><small className="text-[10px] font-bold uppercase text-muted-foreground">Smart billing kitchen</small></span></Link>
        <nav className="ml-auto hidden items-center gap-1 lg:flex">
          <Link to="/computational-thinking" className="nav-link">Thinking</Link><Link to="/architecture" className="nav-link">Architecture</Link><Link to="/testing" className="nav-link">Testing</Link><Link to="/performance" className="nav-link">Performance</Link><Link to="/defence" className="nav-link">Defence Mode</Link>
        </nav>
        <Button variant="secondary" onClick={demo}><Sparkles size={16}/> Demo order</Button>
        <Button onClick={() => setCartOpen(true)}><ShoppingBag size={17}/> <span className="hidden sm:inline">Cart</span><span className="rounded bg-primary-foreground/15 px-2 py-0.5">{itemCount}</span></Button>
      </div>
    </header>

    <main>
      <section className="border-b border-border bg-hero text-hero-foreground">
        <div className="mx-auto grid max-w-[1500px] gap-10 px-5 py-14 lg:grid-cols-[1.25fr_.75fr] lg:px-8 lg:py-20">
          <div><p className="eyebrow">Transparent by design</p><h1 className="mt-4 max-w-4xl font-display text-5xl font-bold leading-[1.05] sm:text-6xl lg:text-7xl">Every flavour.<br/><span className="text-highlight">Every rupee explained.</span></h1><p className="mt-6 max-w-2xl text-lg text-hero-muted">Create your order and follow the exact journey from item price to final bill—discount, delivery and GST included.</p><div className="mt-8 flex flex-wrap gap-3"><Button variant="accent" onClick={() => document.getElementById("menu")?.scrollIntoView({ behavior: "smooth" })}>Explore the menu <ChevronRight size={17}/></Button><Button variant="secondary" onClick={demo}>Load defence demo</Button></div></div>
          <div className="self-end border-l border-hero-border pl-7"><p className="text-sm text-hero-muted">Current order</p><p className="mt-1 font-display text-4xl font-bold">{itemCount} <span className="text-lg font-normal text-hero-muted">items</span></p><p className="mt-6 text-sm text-hero-muted">Menu subtotal</p><p className="font-display text-3xl font-bold text-highlight">{money(previewSubtotal)}</p><div className="mt-7 flex items-center gap-2 text-sm text-hero-muted"><Check size={16} className="text-highlight"/> Final calculation happens securely on the server</div></div>
        </div>
      </section>

      <section id="menu" className="mx-auto max-w-[1500px] px-5 py-12 lg:px-8">
        <div className="flex flex-col justify-between gap-5 md:flex-row md:items-end"><div><p className="eyebrow text-primary">Today’s menu</p><h2 className="mt-2 font-display text-4xl font-bold">Made for a proper feast</h2><p className="mt-2 text-muted-foreground">Twelve favourites, clearly priced and ready to add.</p></div><label className="relative block w-full md:w-80"><Search className="absolute left-3 top-3 text-muted-foreground" size={18}/><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search dishes" className="h-11 w-full rounded-md border border-input bg-card pl-10 pr-4 text-sm outline-none focus:ring-2 focus:ring-ring"/></label></div>
        <div className="mt-7 flex gap-2 overflow-x-auto pb-2">{CATEGORIES.map((name) => <Button key={name} size="sm" variant={category === name ? "primary" : "secondary"} onClick={() => setCategory(name)}>{name}</Button>)}</div>
        <div className="mt-8 grid gap-5 sm:grid-cols-2 xl:grid-cols-3">{filtered.map((item) => { const quantity = cart[item.id] ?? 0; return <article key={item.id} className="group overflow-hidden rounded-md border border-border bg-card shadow-sm transition hover:-translate-y-1 hover:shadow-lg"><div className="relative aspect-[16/10] overflow-hidden bg-muted"><FoodImage src={item.imageUrl} name={item.name}/><span className="absolute left-3 top-3 rounded bg-card/95 px-2 py-1 text-[11px] font-bold uppercase text-primary shadow">{item.category}</span></div><div className="p-5"><div className="flex items-start justify-between gap-3"><h3 className="font-display text-xl font-bold">{item.name}</h3><strong className="whitespace-nowrap text-lg text-primary">{money(item.pricePaise)}</strong></div><p className="mt-2 min-h-10 text-sm leading-5 text-muted-foreground">{item.description}</p><div className="mt-5">{quantity === 0 ? <Button className="w-full" onClick={() => changeQuantity(item.id, 1)}><Plus size={17}/> Add to order</Button> : <div className="flex h-10 items-center justify-between rounded-md border border-primary bg-primary-soft px-2"><Button variant="ghost" size="icon" aria-label={`Remove one ${item.name}`} onClick={() => changeQuantity(item.id, -1)}><Minus size={16}/></Button><span className="text-sm font-bold">{quantity} in order</span><Button variant="ghost" size="icon" aria-label={`Add one ${item.name}`} onClick={() => changeQuantity(item.id, 1)}><Plus size={16}/></Button></div>}</div></div></article>})}</div>
      </section>

      <section className="border-y border-border bg-muted"><div className="mx-auto grid max-w-[1500px] gap-4 px-5 py-9 md:grid-cols-4 lg:px-8">{[["01","Choose dishes"],["02","Build your order"],["03","Apply the best saving"],["04","See the final bill"]].map(([n,label]) => <div key={n} className="flex items-center gap-4"><span className="font-mono text-sm font-bold text-primary">{n}</span><span className="font-semibold">{label}</span></div>)}</div></section>

      {bill && <BillView bill={bill}/>} 
    </main>

    {cartOpen && <div className="fixed inset-0 z-50 flex justify-end bg-overlay" onMouseDown={() => setCartOpen(false)}><aside className="h-full w-full max-w-lg overflow-y-auto bg-background p-6 shadow-2xl" onMouseDown={(e) => e.stopPropagation()}><div className="flex items-center justify-between"><div><p className="eyebrow text-primary">Your order</p><h2 className="font-display text-3xl font-bold">Cart summary</h2></div><Button variant="ghost" size="icon" aria-label="Close cart" onClick={() => setCartOpen(false)}><X/></Button></div>
      <div className="mt-7 divide-y divide-border">{Object.entries(cart).length === 0 ? <div className="py-16 text-center"><ShoppingBag className="mx-auto text-muted-foreground"/><p className="mt-3 font-semibold">Your cart is empty</p></div> : Object.entries(cart).map(([id, quantity]) => { const item = MENU.find((entry) => entry.id === id); if (!item) return null; return <div key={id} className="flex items-center gap-3 py-4"><div className="min-w-0 flex-1"><b className="block truncate">{item.name}</b><small className="text-muted-foreground">{money(item.pricePaise)} each</small></div><div className="flex items-center gap-1"><Button variant="secondary" size="icon" aria-label={`Decrease ${item.name}`} onClick={() => changeQuantity(id,-1)}><Minus size={14}/></Button><span className="w-7 text-center font-bold">{quantity}</span><Button variant="secondary" size="icon" aria-label={`Increase ${item.name}`} onClick={() => changeQuantity(id,1)}><Plus size={14}/></Button></div><b className="w-20 text-right">{money(item.pricePaise*quantity)}</b><Button variant="ghost" size="icon" aria-label={`Remove ${item.name}`} onClick={() => setCart((c) => { const next={...c}; delete next[id]; return next; })}><Trash2 size={15}/></Button></div>})}</div>
      <div className="mt-6 border-t border-border pt-5"><div className="flex justify-between text-muted-foreground"><span>Menu subtotal</span><b className="text-foreground">{money(previewSubtotal)}</b></div><label className="mt-5 block text-xs font-bold uppercase text-muted-foreground">Coupon code</label><input value={coupon} onChange={(e) => setCoupon(e.target.value.toUpperCase())} placeholder="WELCOME50, SAVE10 or FESTIVE20" className="mt-2 h-11 w-full rounded-md border border-input bg-card px-3 text-sm outline-none focus:ring-2 focus:ring-ring"/>{error && <p role="alert" className="mt-3 text-sm font-semibold text-destructive">{error}</p>}<Button className="mt-5 w-full" disabled={loading || itemCount === 0} onClick={runBill}><ReceiptText size={17}/>{loading ? "Calculating…" : "Generate final bill"}</Button><p className="mt-3 text-center text-xs text-muted-foreground">Discount, delivery and GST are validated on the server.</p></div>
    </aside></div>}
  </div>;
}

function BillView({ bill }: { bill: BillResult }) {
  const stages = [
    ["1", "Order items", `${bill.items.length} unique dishes`], ["2", "Item totals", "Price × quantity for every line"], ["3", "Subtotal", money(bill.subtotal)],
    ["4", "Discount", `${bill.discountLabel}: −${money(bill.discount)}`], ["5", "Delivery", bill.delivery ? money(bill.delivery) : "FREE"], ["6", "GST at 5%", money(bill.gst)], ["7", "Final bill", money(bill.total)],
  ];
  return <section id="bill" className="border-t border-border bg-invoice py-14 print:bg-background print:py-0"><div className="mx-auto max-w-6xl px-5 lg:px-8"><div className="mb-7 flex flex-wrap items-end justify-between gap-4 print:hidden"><div><p className="eyebrow text-primary">Calculation complete</p><h2 className="font-display text-4xl font-bold">Every step, accounted for.</h2></div><Button variant="secondary" onClick={() => window.print()}><Printer size={17}/> Print / Save PDF</Button></div><div className="grid gap-7 lg:grid-cols-[.85fr_1.15fr] print:block">
    <div className="space-y-2 print:hidden">{stages.map(([n,title,value]) => <div key={n} className="flex items-center gap-4 rounded-md border border-border bg-card p-4"><span className="grid size-9 shrink-0 place-items-center rounded bg-primary text-sm font-bold text-primary-foreground">{n}</span><div className="min-w-0 flex-1"><b>{title}</b><p className="text-sm text-muted-foreground">{value}</p></div><ChevronRight size={17} className="text-muted-foreground"/></div>)}</div>
    <article className="rounded-md border border-border bg-card p-6 shadow-xl print:border-0 print:shadow-none"><div className="flex justify-between gap-4 border-b border-border pb-5"><div><span className="grid size-10 place-items-center rounded-md bg-primary text-primary-foreground"><UtensilsCrossed size={19}/></span><h3 className="mt-3 font-display text-2xl font-bold">Rasoi Route</h3><p className="text-sm text-muted-foreground">Tax invoice · India</p></div><div className="text-right text-sm"><b>{bill.orderId}</b><p className="mt-1 text-muted-foreground">{new Date(bill.createdAt).toLocaleString("en-IN")}</p></div></div>
      <table className="mt-5 w-full text-sm"><thead><tr className="border-b border-border text-left text-xs uppercase text-muted-foreground"><th className="py-3">Item</th><th className="py-3 text-center">Qty</th><th className="py-3 text-right">Price</th><th className="py-3 text-right">Total</th></tr></thead><tbody>{bill.items.map((item)=><tr key={item.itemId} className="border-b border-border"><td className="py-3 font-semibold">{item.name}</td><td className="py-3 text-center">{item.quantity}</td><td className="py-3 text-right">{money(item.unitPrice)}</td><td className="py-3 text-right font-semibold">{money(item.total)}</td></tr>)}</tbody></table>
      <div className="ml-auto mt-5 max-w-xs space-y-2 text-sm"><Line label="Subtotal" value={money(bill.subtotal)}/><Line label={bill.discountLabel} value={`−${money(bill.discount)}`}/><Line label={bill.deliveryLabel} value={bill.delivery ? money(bill.delivery) : "FREE"}/><Line label="GST (5%)" value={money(bill.gst)}/><div className="mt-4 flex justify-between border-t-2 border-foreground pt-4 font-display text-2xl font-bold"><span>Grand total</span><span>{money(bill.total)}</span></div></div><div className="mt-7 border-t border-dashed border-border pt-5 text-center"><p className="font-display text-xl font-bold text-primary">Thank you for ordering!</p><p className="mt-1 text-xs text-muted-foreground">This bill was recalculated and validated on the server.</p></div>
    </article>
  </div></div></section>;
}

function Line({ label, value }: { label: string; value: string }) { return <div className="flex justify-between gap-4"><span className="text-muted-foreground">{label}</span><b>{value}</b></div>; }