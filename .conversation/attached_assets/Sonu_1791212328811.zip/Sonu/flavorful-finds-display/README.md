# Savory Delights Showcase

For every food item, add a high-quality food image.

Use publicly accessible food image URLs from a reliable image source such as Unsplash.

Do not use random broken URLs.

Each menu item must have:

- name

- category

- price

- description

- image URL

Use appropriate images for:

Chicken Biryani

Chicken 65

Masala Dosa

Paneer Butter Masala

Idli

Vada

Veg Fried Rice

Chicken Fried Rice

Butter Naan

Samosa

Gulab Jamun

Mango Lassi

If an external image cannot be reliably loaded, provide a local fallback image so the UI never shows a broken image.

Keep image loading optimized using lazy loading.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/b031fa24-dd7e-440f-9f2e-ca0435a92208).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
